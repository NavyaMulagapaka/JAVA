package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.TakeCareClinicException.TakeCareClinicException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;

public class PatientService implements IPatientService {
	
	IPatientDAO patientDao = new PatientDAO();
	
	
	@Override
	public boolean validatePatientDetails(PatientBean patient)
			throws TakeCareClinicException {
		List<String> list = new ArrayList<>();
		boolean result = false;

		if (!isNameValid(patient.getPatientName())) {
			list.add("Name should start with capital letter & length should be greater than 4 and less tah 20");
		}
		if (!isPhonevalid(patient.getPhone())) {
			list.add("Phone number exactly 10 digits");
		}
		if (!isProblemValid(patient.getDescription())) {
			list.add("Problem name should contain only alphabets");
		}

		if (!list.isEmpty()) {
			result = false;
			throw new TakeCareClinicException(list + "");
		} else {
			result = true;
		}
		return result;
	}
	
	
	
private boolean isNameValid(String patientName) {
		
	
	String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,20}";
	Pattern pattern = Pattern.compile(nameRegEx);
	Matcher matcher = pattern.matcher(patientName);
	return matcher.matches();
		
	}
	
	
	private boolean isPhonevalid(long phone) {
		
		
		String phoneregEx = "[0-9]{10}";
		Pattern pattern = Pattern.compile(phoneregEx);
		Matcher matcher = pattern.matcher(String.valueOf(phone));
		return matcher.matches();
		
		
	}





private boolean isProblemValid(String description) {
	
	String nameRegEx = "[a-zA-Z]{3,}";
	Pattern pattern = Pattern.compile(nameRegEx);
	Matcher matcher = pattern.matcher(description);
	return matcher.matches();
	
	
	}





	@Override
	public int getId(PatientBean patient) throws TakeCareClinicException {
		
		return patientDao.getId(patient);
		
	}

	
	
	@Override
	public PatientBean getPatientById(int id) throws TakeCareClinicException {
		
	
		return patientDao.getPatientById(id);
	}

	
	

}
