package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.TakeCareClinicException.TakeCareClinicException;

public interface IPatientService {
	boolean validatePatientDetails(PatientBean patient) throws TakeCareClinicException;

	int getId(PatientBean patient) throws TakeCareClinicException;

	public PatientBean getPatientById(int id) throws TakeCareClinicException;

	
	
}
