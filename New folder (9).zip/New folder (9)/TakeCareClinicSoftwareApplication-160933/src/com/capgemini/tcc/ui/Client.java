package com.capgemini.tcc.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.TakeCareClinicException.TakeCareClinicException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;


public class Client {

	
	static Logger logger = Logger.getLogger(Client.class);
	public static void main(String[] args)  {
		
			PropertyConfigurator.configure("resource/log4j.properties");
			logger.info("log4j file loaded...");

			Scanner scanner = new Scanner(System.in);
			IPatientService service = new PatientService();
			System.out.println("welcome to  TakeCare Clinic Software Application");
			System.out.println("1.Add Patient Details");
			System.out.println("2.Search Patient Details by Id");
			System.out.println("3.Exit");
			System.out.println("Select the Options");
			int choice = 0;
			try {
				choice = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("enter only digits");
				System.exit(0);
			}
			switch (choice) {
			case 1:
				scanner.nextLine();
				System.out.println("Enter Patientname:");
				String name = scanner.nextLine();
				System.out.println("Enter PatientAge:");
				int age = 0;
				try {
					age = scanner.nextInt();
				} catch (InputMismatchException e) {
					System.err.println("phone number should contain only digits");
					System.exit(0);
				}
				System.out.println("Enter MobileNumber:");
				long phone = 0;
				try {
					phone = scanner.nextLong();
				} catch (InputMismatchException e) {
					System.err.println("Phone number should contain only Digits");
					System.exit(0);
				}
				scanner.nextLine();
				System.out.println("Problem Description");
				String problemName = scanner.nextLine();

				PatientBean patient = new PatientBean();
				patient.setPhone(phone);
				patient.setPatientName(name);
				patient.setDescription(problemName);
				patient.setAge(age);

				try {
					boolean result = service.validatePatientDetails(patient);

					if (result) {
						int patientId = service.getId(patient);
						System.out.println("Your Appointment is fixed with Id: " + patientId);
					}

				} catch (TakeCareClinicException e) {
					System.err.println(e.getMessage());
				}
				break;

			case 2:
				System.out.println("Enter Patient Id to know details");
				int id = scanner.nextInt();

				try {
					PatientBean p = service.getPatientById(id);
					System.out.println("---------------------");
					System.out.println("id :" + id);
					System.out.println("name :" + p.getPatientName());
					System.out.println("Age :" + p.getAge());
					System.out.println("Phone :" + p.getPhone());
					System.out.println("Description :" + p.getDescription());
					System.out.println("Description :" + p.getConsultationDate());
				} catch (Exception e)  {
					
					try {
						throw new TakeCareClinicException("There is no patient with this Id");
					} catch (TakeCareClinicException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				break;
				
			case 3:
					System.out.println("You exited from the Application");
				break;

			}
			scanner.close();
		}
			
	}


