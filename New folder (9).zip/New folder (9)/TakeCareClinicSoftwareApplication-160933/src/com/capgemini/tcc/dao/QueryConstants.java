package com.capgemini.tcc.dao;

public interface QueryConstants {

	public static final String insertQuery = "insert into Patient values(Patient_Id_Seq.nextval,?,?,?,?,sysdate)";
	public static final String getIdQuery = "select max(patient_id) from patient";
	public static final String selectQuery = "select * from patient where patient_id= ?";
	

}
