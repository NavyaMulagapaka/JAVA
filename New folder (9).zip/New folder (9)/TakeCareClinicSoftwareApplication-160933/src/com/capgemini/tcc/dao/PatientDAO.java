package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.tcc.TakeCareClinicException.TakeCareClinicException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.QueryConstants;
import com.capgemini.tcc.utility.JdbcUtility;

public class PatientDAO implements IPatientDAO{

	static Logger logger = Logger.getLogger(PatientDAO.class);

	Connection connection = null;
	PreparedStatement statement = null;
	
	/**
	 * Method Name:getId(PatientBean patient) 
	 * 
	 * Purpose:This Method takes patient of type PatientBean as input and stores the details of patients
	 * like patient name,patient age,patient phone number,patient problem Description
	 * 
	 * Return type: This method automatically return Id when the details entered.
	 */
	
	
	@Override
	public int getId(PatientBean patient) throws TakeCareClinicException {
		logger.info("in fix appoiment method..");

		int patientId = 0;

		connection = JdbcUtility.getConnection();
		try {
				statement = connection.prepareStatement(QueryConstants.insertQuery);
				statement.setString(1, patient.getPatientName());
				statement.setInt(2, patient.getAge());
				statement.setLong(3, patient.getPhone());
				statement.setString(4, patient.getDescription());
				
				statement.executeUpdate();

				statement = connection.prepareStatement(QueryConstants.getIdQuery);
				ResultSet resultSet = statement.executeQuery();
				resultSet.next();

				patientId = resultSet.getInt(1);

			} catch (SQLException e) {
				logger.error("statement not created 1");
				throw new TakeCareClinicException("statement not created 1");
				

			}
		

		return patientId;
	}
	
	/**
	 * Method Name:getPatientById(int id)
	 * 
	 * Purpose: This method takes Id of the Patient as input and gives the details of the patients from data base.
	 * 
	 * Return Type: This method returns Patient Details of type PatientBean
	 */
	
	

	@Override
	public PatientBean getPatientById(int id) throws TakeCareClinicException {
logger.info("in fix appoiment method..");

		
		connection = JdbcUtility.getConnection();
		PatientBean p;
		try{
			statement = connection.prepareStatement(QueryConstants.selectQuery);
			statement.setInt(1, id);
			
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
				p=new PatientBean();
				p.setPatientId(resultSet.getInt(1));
				p.setPatientName(resultSet.getString(2));
				p.setAge(resultSet.getInt(3));
				p.setPhone(resultSet.getLong(4));
				p.setDescription(resultSet.getString(5));
				p.setConsultationDate(resultSet.getDate(6));
				
			return p;
			
			
		}
		catch(SQLException e)
		{
			logger.error("statement not created 2");
			
			throw new TakeCareClinicException("statement not created 2");
		}
	}

	
	
	
	
}
