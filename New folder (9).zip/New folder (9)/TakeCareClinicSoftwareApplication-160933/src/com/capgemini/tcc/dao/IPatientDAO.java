package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.TakeCareClinicException.TakeCareClinicException;

public interface IPatientDAO {

	int getId(PatientBean patient) throws TakeCareClinicException;
	public PatientBean getPatientById(int id) throws TakeCareClinicException;
	
	
	
	
}
