package com.cg.soap;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class HelloWorldClient {

	public static void main(String[] args) throws MalformedURLException {
		URL u= new URL("http://localhost:5000/hs?wsdl");  //each and every package will be url
		QName q = new QName("http://soap.cg.com/", "HelloWorldImplService"); //Query name
		
		Service s = Service.create(u,q);
		HelloWorld h = s.getPort(HelloWorld.class);
		System.out.println(h.sayHello());
	}

}
