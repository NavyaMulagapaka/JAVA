package com.cg.soap;

import javax.jws.WebService;


@WebService(endpointInterface="com.cg.soap.HelloWorld")
public class HelloWorldImpl implements HelloWorld {

	public String sayHello() {
	
		return "HEllo, good afternoon";
	}

	
	
	
	
	
	
	
	
}
