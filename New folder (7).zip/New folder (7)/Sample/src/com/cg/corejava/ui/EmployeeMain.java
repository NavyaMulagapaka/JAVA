package com.cg.corejava.ui;

import java.util.Scanner;

import com.cg.corejava.bean.Employee;
import com.cg.corejava.exception.EmployeeException;
import com.cg.corejava.service.Service;

public class EmployeeMain {

	
		public static void main(String[] args) {

			// TODO Auto-generated method stub

			Scanner sc=new Scanner(System.in);

			System.out.println("Enter id of the employee:");

			int id=sc.nextInt();

			System.out.println("Enter name of the employee:");

			String name=sc.next();

			//System.out.println("Enter designation of the employee:\n System Associate \nProgrammer \n Manager \n Clerk");

			//String des=sc.next();

			System.out.println("Enter salary of the employee:");

			long salary =sc.nextLong();
			String designation = null;
			
			if(salary>5000&&salary<20000)
			{
				designation="System Associate";
			}
			if(salary>=20000&&salary<40000)
			{
				designation="Programmer";
			}
			if(salary>=40000)
			{
				designation="Manager";
			}
			if(salary<5000)
			{
				designation="Clerk";
			}
			
			
			Employee e=new Employee(id, name, salary, designation);

			String n=e.designation;

			double d=e.salary;

			Service s=new Service();

			s.insuranceScheme(d,n);

			s.display();

			EmployeeException b=new EmployeeException();

			}

			

	}


