package com.cg.corejava.exception;

public class balCheck extends Exception {

	

	 public void check()
	 {
	  System.out.println("salary is less than 3000");
	 }
}
