package com.cg.corejava.exception;

import  com.cg.corejava.bean.Employee;
import com.cg.corejava.service.Service;


public class EmployeeException {

	{

	 try
	 {
	  if(Employee.salary<3000)
	  {
	   throw new balCheck();
	  }
	 }
	 catch(Exception e)
	 {
	  balCheck b=new balCheck();
	  b.check();
	 }
	 
	}
	
}
