package com.cg.corejava.service;



import  com.cg.corejava.bean.Employee;

interface EmployeeService

{

void insuranceScheme(double s,String s1);

void display();

}

public class Service implements EmployeeService

{

double s=Employee.salary;

String s1=Employee.designation;

//String s2=Employee.insurance;

public void insuranceScheme(double s,String s1)

{

if(s>5000 && s<20000 && s1=="System Associate")

{

Employee.insurance="Scheme A";

}

else if(s>=20000 && s<40000 && s1=="Programmer")

{

Employee.insurance="Scheme B";

}

else if(s>=40000 && s1=="Manager")

{

Employee.insurance="Scheme C";

}

else if(s<5000 && s1=="Clerk")

{

Employee.insurance="No scheme";

}

else

Employee.insurance="Your profile is not applicable for insurance any scheme";

}

public void display()

{

System.out.println("Person Details:");

System.out.println("---------------------");

System.out.println(" Name: "+Employee.name);

System.out.println("Id: "+Employee.id);

System.out.println("Designation : "+Employee.designation);

System.out.println("Salary: "+Employee.salary);

System.out.println("Insurance Scheme: "+Employee.insurance);

}

}