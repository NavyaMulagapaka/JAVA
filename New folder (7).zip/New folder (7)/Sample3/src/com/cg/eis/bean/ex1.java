package com.cg.eis.bean;

class ex{
	void m1()
	{
		System.out.println("Running");
	}
}
class ex1 extends ex
{
	void m1()
	{
		System.out.println("Running with speed");
	}
	public static void main(String[] args)
	{
		
		ex e= new ex();
		
		ex1 ex= new ex1();
		e.m1();
		ex.m1();
	}
	
}