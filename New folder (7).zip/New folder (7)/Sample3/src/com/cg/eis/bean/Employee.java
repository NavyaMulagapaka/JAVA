package com.cg.eis.bean;

public class Employee {

	public int id;
	public String name;
	public double Salary;
	public String designation;
	public String insurance;
	
	public Employee() {
		super();
	}

	public Employee(double salary, String designation) {
		super();
		Salary = salary;
		this.designation = designation;
	}


	
	
	
}



