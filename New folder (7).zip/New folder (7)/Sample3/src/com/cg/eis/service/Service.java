package com.cg.eis.service;

interface EmployeeService{
	
	void details(double s,String d);
	void display();
	
}

public class Service implements EmployeeService{

	@Override
	public void details(double s, String d) {
		
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
	

}
