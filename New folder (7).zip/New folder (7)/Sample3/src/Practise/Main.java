package Practise;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {

		validate val = new validate();
		String name;
		long mobNumber;
		long panCardNum;

		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter your Id");
		String id = sc.nextLine();
		if (val.isId(id) == true) {
			System.out.println("valid");
		} else {
			System.out.println("invalid");
		}

	}

}
