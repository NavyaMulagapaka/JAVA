package Practise;

import java.util.regex.Pattern;

public class validate {

	public boolean isId(String id) {
		boolean flag = false;
		if (Pattern.matches("[0-9]{3}", id)) {
			flag = true;
		}
		return flag;

	}
}
