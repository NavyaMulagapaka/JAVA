package com.cg.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistCustomer {

	public static void main(String[] args) {
		


	EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpademo1");
	
	EntityManager em= factory.createEntityManager();
	em.getTransaction().begin();
	Customer c= new Customer();
	c.setId(123);
	c.setName("mukesh");
	c.setCity("mumbai");
	
	
	em.persist(c);
	
	em.getTransaction().commit();
	
	System.out.println("Customer entity is persisted");
	
	
	}

}
