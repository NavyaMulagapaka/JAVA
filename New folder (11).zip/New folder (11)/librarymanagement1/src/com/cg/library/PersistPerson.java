package com.cg.library;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistPerson {

	public static void main(String[] args) {
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("librarymanagement1");
		
		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		
		
		Employee e1= new Employee(124,"pooja", 55000.0);
		em.persist(e1);
		em.getTransaction().commit();
		
		
		

		em.close();
		
	
		

	}

}
