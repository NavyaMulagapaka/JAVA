package com.cg.library;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UpadateLibrary {

	public static void main(String[] args) {
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("librarymanagement1");
		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		Library lib1= new Library();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter id");
		int id=sc.nextInt();
		
		Library l2= em.find(Library.class, id);
		
		if(l2==null)
		{
			System.out.println("id not present");
		}
		else
		{
			
			System.out.println("sucessfully done");
			System.out.println("Enter bookname");
			String bname= sc.next();
			System.out.println("Eneter book price");
			double bprice= sc.nextDouble();
			l2.setBookName(bname);
			l2.setBookPrice(bprice);
			em.persist(l2);
		}
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
		
		
		
		
		
		
		
		
		

	}

}
