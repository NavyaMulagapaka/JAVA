package com.cg.library;

import java.util.*;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
//@Inheritance(strategy=InheritanceType.JOINED)//we will get both tables if we write joined

//@Inheritance(strategy=InheritanceType.Single_Table)
//Thats's why it generates only one table for parent child class
													// i.e person table

@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)//jpa generates table values only for child entities but not for parent entities
public class Person {

	
	@Id
	private int id;
	private String name;
	
	

	public Person() {
		super();
	}

	public Person(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	}
	
	
	
	
	

