package com.cg.library;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class DeleteLibrary {

	public static void main(String[] args) {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("librarymanagement1");
		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		Library lib1= new Library();
		
	
		
		Library l2= em.find(Library.class, 1);
		em.remove(l2);
		System.out.println("Deleted Successfully");
		
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	


	}

}
