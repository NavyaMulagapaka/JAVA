package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		PrintWriter out= response.getWriter();
		
		
		String username=request.getParameter("user");
		
		String password=request.getParameter("pass");
		
		String email= request.getParameter("email");
		
		String number = request.getParameter("mnum");
		
		/*out.println("<html>");
		
		out.println("<body bgcolor='yellow'>");
				
		out.print("<p>Welcome Mr."+username+"</p>");
		
		out.print("<p>You entered password:"+password+"</p>");
		
		out.print("<p>Your emailId:"+email+"</p>");
		
		out.print("<p>Your mobile num:"+number+"</p>");
		
		out.println("You have registered sucessfully please login here");
		
		out.println("</body></html>");*/
		
		
		
		/*RequestDispatcher rs = request.getRequestDispatcher("login.jsp");
		
		rs.include(request, response);*/
		
		
		UserDao dao= new UserDao();
		
		int n= dao.add(username, password, email, number);
		
		if(n>0)
		{
			
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request,response);
		}
		else
		{
			out.println("something went wrong");
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			rd.include(request, response);
		}
		
		
		
		
		
		
	}

}
