package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.UserDao;

/**
 * Servlet implementation class ForPassServlet
 */
@WebServlet("/ForPassServlet")
public class ForPassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		
		String mobile=request.getParameter("mnum");
		
		UserDao dao= new UserDao();
		
		boolean flag= dao.getMobile(mobile);
		
		if(flag)
		{
			out.println("Create your new password");
			RequestDispatcher rd = request.getRequestDispatcher("newpassword.jsp?phone="+mobile);
			rd.include(request,response);
		}
		else
		{
			out.println("something went wrong please enter your mobile number");
			RequestDispatcher rd = request.getRequestDispatcher("forgetpassword.jsp");
			rd.include(request, response);
		}
		
		
	}

}
