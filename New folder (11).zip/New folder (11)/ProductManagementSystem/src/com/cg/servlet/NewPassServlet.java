package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.UserDao;

/**
 * Servlet implementation class NewPassServlet
 */
@WebServlet("/NewPassServlet")
public class NewPassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		
		String mobile=request.getParameter("mnumber");
		String npass=request.getParameter("npass");
		String cpass = request.getParameter("cpass");
		
		if(npass.equals(cpass))
		{
			UserDao dao= new UserDao();
			
			int n= dao.updatePassword(cpass, mobile);
			
			if(n>0)
			{
				out.println("Your password Updated Sucessfully login again");
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.include(request,response);
			}
			else
			{
				out.println("Something went wrong please try again");
				RequestDispatcher rd = request.getRequestDispatcher("newpassword.jsp");
				rd.include(request, response);
			}
			
		}
		else
		{
			out.println("Enter correct confirm password");
			RequestDispatcher rd = request.getRequestDispatcher("newpassword.jsp");
			rd.include(request,response);
		}
		
		
		
		
		
		
		
		
		
		
		
	}

}
