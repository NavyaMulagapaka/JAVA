package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.UserDao;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		
		String id=request.getParameter("id");
		
		String product_price=request.getParameter("pprice");
		
		UserDao dao= new UserDao();
		
		int n= dao.editDetails(id, product_price);
		
		if(n>0)
		{
			out.println("Successfully entered product details");
			RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
			rd.include(request,response);
		}
		else
		{
			out.println("something went wrong");
			RequestDispatcher rd = request.getRequestDispatcher("viewall.jsp");
			rd.include(request, response);
		}
		
	}

}
