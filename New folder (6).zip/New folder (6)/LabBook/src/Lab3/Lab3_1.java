package Lab3;

public class Lab3_1 {

	public static void main(String[] args) {
		

	}

}
