import java.util.Scanner;


public class Lab2_4 {

	int age;
	double weight;
	String FirstName;
	String LastName;
	String Gender;
	String MobileNumber;
	public Lab2_4() {
		super();
	}
	public Lab2_4(int age, double weight, String firstName, String lastName,
			String gender, String mobileNumber) {
		super();
		this.age = age;
		this.weight = weight;
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
		MobileNumber = mobileNumber;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		MobileNumber = mobileNumber;
	}
	
	public String toString() {
		return "Personal Details:"+'\n'+"------------"+'\n' +"age=" + age +'\n'+ "weight=" + weight +'\n'+ "FirstName="
				+ FirstName + '\n'+"LastName=" + LastName +'\n'+ "Gender=" + Gender+'\n'+"Mobile Number"+MobileNumber;
		
	}
	
	
	public static void main(String[] args) {
		Lab2_4 p=new Lab2_4();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		if(age>=0){
		p.age=age;
		}
		else
		{
			System.out.println("Enter valid Age");
		}
	    System.out.println("Enter weight");
		double weight=sc.nextInt();
		p.weight=weight;
		
		System.out.println("Enter FirstName");
		String FirstName=sc.next();
		p.FirstName=FirstName;
		
		System.out.println("Enter LastName");
		String LastName=sc.next();
		p.LastName=LastName;
		
		System.out.println("Eneter Gender");
		String  Gender=sc.next();
		
		if(Gender.equalsIgnoreCase("M")||Gender.equalsIgnoreCase("F"))
		{
			p.Gender= Gender;
		}
		else
		{
			System.out.println("Enter valid Gender");
		} 
		System.out.println("Enter Mobile Number");
	
		String  MobileNumber=sc.next();
	
		if(MobileNumber.length()==10)
		{
			p.MobileNumber= MobileNumber;
		}
		else
		{
		System.out.println("Enter valid MobileNumberr");
		} 
	
		System.out.println(p.toString());
	
	}
	
}
	
	

