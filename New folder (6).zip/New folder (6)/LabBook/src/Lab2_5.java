import java.util.Scanner;



enum Gender{
	M,F;
}

public class Lab2_5 {
	

	int age;
	double weight;
	String FirstName;
	String LastName;
	 Gender gender;
	String MobileNumber;

	public Lab2_5() {
		super();
	}

	public Lab2_5(int age, double weight, String firstName, String lastName,
			Gender gender, String mobileNumber) {
		super();
		this.age = age;
		this.weight = weight;
		FirstName = firstName;
		LastName = lastName;
		this.gender = gender;
		MobileNumber = mobileNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getMobileNumber() {
		return MobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		MobileNumber = mobileNumber;
	}

	@Override
	public String toString() {
		return "Personal Details:"+'\n'+"------------"+'\n' +"age=" + age +'\n'+ "weight=" + weight +'\n'+ "FirstName="
				+ FirstName + '\n'+"LastName=" + LastName +'\n'+ "Gender=" + gender+'\n'+"Mobile Number"+MobileNumber;
		
	}

	public static void main(String[] args) {
		Lab2_5 p=new Lab2_5();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		if(age>=0){
		p.age=age;
		}
		else
		{
			System.out.println("Enter valid Age");
		}
	    System.out.println("Enter weight");
		double weight=sc.nextInt();
		p.weight=weight;
		
		System.out.println("Enter FirstName");
		String FirstName=sc.next();
		p.FirstName=FirstName;
		
		System.out.println("Enter LastName");
		String LastName=sc.next();
		p.LastName=LastName;
		
		Gender c1=Gender.M;
		Gender c2=Gender.F;
		System.out.println("Select 1 for male and 2 for Female");
		int c3=sc.nextInt();
		Gender gender;
		if(c3==1)
		{
			gender=c1;
		}
		else
		{
			gender=c2;
		}
		
		System.out.println("Enter Mobile Number");
		String MobileNumber=sc.next();
		p.MobileNumber=MobileNumber;
		
		System.out.println(p.toString());
		
	}
	
	
	
}
