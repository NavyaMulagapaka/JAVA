package Lab4;

public class CurrentAccount extends Account{

	
	final double overDraftLimit=10000.0;
	
	
	
	public boolean withDraw(double a,double b)
	{
		b=b-a;
		if(b<overDraftLimit)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static void main (String[] args)
	{
		CurrentAccount ca=new CurrentAccount();
		Person p1 = new Person(34,"Smith");
		Account acc=new Account(20000,p1);
		
		if(ca.withDraw(3000, acc.balance)==true)
		{
			System.out.println(acc.balance);
			System.out.println("Over draft limit is crossed");
		}
		else
		{
			acc.withDraw(2000);
			System.out.println(acc.GetBalance());
		}
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
}
