package Lab4;

public class savingsAccount extends Account{

	final int minBalance=500;
	
	public void withDraw(double a,double b)
	{
			b=b-a;
		if(b>=minBalance)
		{
			System.out.println("balance is "+b);
		}
		else
		{
			System.out.println("No sufficient balance");
		}
	}
	
	public static void main(String [] args)
	{
		savingsAccount sa=new savingsAccount();
		Person p1 = new Person(34,"Smith");
		Account acc=new Account(2000,p1);
		
		sa.withDraw(2500, acc.balance);
	}
	
}
