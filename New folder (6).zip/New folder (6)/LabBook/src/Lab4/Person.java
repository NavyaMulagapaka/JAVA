package Lab4;

public class Person {

	int age;
	String Name;
	public Person() {
		super();
	}
	public Person(int age, String name) {
		super();
		this.age = age;
		Name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	
	

	
	
	
	
	
	
	
	
	
}
