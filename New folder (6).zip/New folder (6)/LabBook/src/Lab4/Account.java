package Lab4;

public class Account extends Person {
	
	
	 static  long accNumber=100;
	double balance;
	Person accHolder;
	int age;
	String name;
	
	public Account() {
		super();
		
	}
	
	public Account(double balance,Person accHolder) {
		accNumber=1+accNumber;
		this.balance = balance;
		this.accHolder=accHolder;
	}


	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	
	public  void deposit(double a)
	{	
		balance=balance+a;
		System.out.println("Amoount deposited"+a);
	}
	
	public void withDraw(double a)
	{
		balance=balance-a;
		System.out.println("Amount with drawn "+a);
	}
	public double GetBalance()
	{
		return balance;
		
	}
	
	
	
	@Override
	public String toString() {
		return "Account [balance=" + balance+ ", age=" + accHolder.age + ", name=" +accHolder.Name + ", accNumber="+accNumber+"]";
	}

	public static void main(String[] args)
	{
		
		Person p1 = new Person(34,"Smith");
		Person p2 = new Person(25,"kathy");
		Account acc1 = new Account(2000,p1);
		System.out.println(acc1);
		
		Account acc2 = new Account(3000,p2);
		
		
		System.out.println(acc2);
		
		acc1.deposit(2000.0);
		
		acc2.withDraw(2000.0);
		System.out.println("Smith account balance is = "+acc1.GetBalance());
		System.out.println("Kathy account balance is = "+acc2.GetBalance());
		 
		
		
	}
	
	
	
	

}
