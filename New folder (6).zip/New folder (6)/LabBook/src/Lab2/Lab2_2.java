package Lab2;
import java.util.Scanner;


public class Lab2_2 {

	public static void main(String[] args) {
		
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a number");
		int i=sc.nextInt();
		if(i>=0)
		{
			System.out.println("Given number is Positive Number");
		}
		else
		{
			System.out.println("Given number is negative number");
		}
		
		
		

	}

}
