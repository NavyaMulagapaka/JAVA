package Lab2;
import java.util.Scanner;


public class PersonMain {

	public static void main(String[] args) {
		Person p=new Person();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		if(age>=0){
		p.age=age;
		}
		else
		{
			System.out.println("Enter valid Age");
		}
	    System.out.println("Enter weight");
		double weight=sc.nextInt();
		p.weight=weight;
		
		System.out.println("Enter FirstName");
		String FirstName=sc.next();
		p.FirstName=FirstName;
		
		System.out.println("Enter LastName");
		String LastName=sc.next();
		p.LastName=LastName;
		
		System.out.println("Eneter Gender");
		String  Gender=sc.next();
		
		if(Gender.equalsIgnoreCase("M")||Gender.equalsIgnoreCase("F"))
		{
			p.Gender= Gender;
		}
		else
		{
			System.out.println("Enter valid Gender");
		} 
		
		System.out.println(p.toString());
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
