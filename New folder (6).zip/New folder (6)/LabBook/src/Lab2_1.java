
public class Lab2_1 {

	public static void main(String[] args) {
		
		String FirstName="Divya";
		String LastName="Bharati";
		String Gender="M";
		int age=25;
		double weight=45.5;
		
		System.out.println("Personal Details"+'\n'+"---------------"+'\n'+"First Name: "+FirstName+'\n'+"Last Name: "+LastName+'\n'+"Gender: "+Gender+'\n'+"age: "+
				age+'\n'+"Weight: "+weight);
		
	}

}
