
public class Person {

	int age;
	double weight;
	String FirstName;
	String LastName;
	String Gender;
	
	public Person() {
		super();
		
	}

	public Person(int age, double weight, String firstName, String lastName,
			String gender) {
		super();
		this.age = age;
		this.weight = weight;
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	@Override
	public String toString() {
		return "Personal Details:"+'\n'+"------------"+'\n' +"age=" + age +'\n'+ "weight=" + weight +'\n'+ "FirstName="
				+ FirstName + '\n'+"LastName=" + LastName +'\n'+ "Gender=" + Gender;
		
	}
	
	
	

	
	
	
	
	
	
	
	
	
}
