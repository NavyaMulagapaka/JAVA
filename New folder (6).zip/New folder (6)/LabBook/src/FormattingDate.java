
public class FormattingDate {

	public static void main(String[] args) {
	

	}

}
