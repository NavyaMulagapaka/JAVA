package Lab7;

import java.util.*;

public class Lab7_2 {

	public static void main(String[] args) {
		
		ArrayList<String> al= new ArrayList<String>();
		
		al.add("Pencil");
		al.add("Book");
		al.add("Bag");
		al.add("Sketch");
		al.add("Marker");
		al.add("Pen");
		
		Collections.sort(al);
		
		for(String obj:al)
		{
		System.out.println(obj);
		}
		
		
		
		
	}

}
