package Lab7;

public class Lab7_1 {

		static String str[]={"pen","book","pencil","sketch","marker","bag"};

		public static void main(String[] args) {

		// TODO Auto-generated method stub

		for(int i=0;i<str.length;i++)

		{
				//System.out.println(str[i]);
		for(int j=i+1;j<str.length;j++)

		{	//System.out.println(str[i]);

		if((str[i]).compareTo(str[j])>0)

		{
			//System.out.println(str[j]);
		String temp=str[i];
		//System.out.println(temp);

		str[i]=str[j];
		/*System.out.println(str[i]);*/

		str[j]=temp;

		}

		}
		/*System.out.println(str[1].toUpperCase());*/
		

		System.out.println(str[i].toUpperCase());

		}
		//System.out.println(str[0].compareTo(str[1].toUpperCase()));
		}

		

	}


