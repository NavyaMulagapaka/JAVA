package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.bean.Mobile;

public interface iMobileService {
	
	public String display();
	public List<Mobile> getMobileByPrice(double price);
	public List<Mobile> getAllMobilesDetails();
	public boolean validateFields();

}
