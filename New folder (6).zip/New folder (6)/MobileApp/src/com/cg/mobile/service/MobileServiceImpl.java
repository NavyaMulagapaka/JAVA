package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.dao.iMobileDao;

public class MobileServiceImpl implements iMobileService {

	iMobileDao dao= new MobileDaoImpl();
	
	
	@Override
	public String display() {
		
		return dao.display();
	}


	@Override
	public List<Mobile> getMobileByPrice(double price) {
		
		return dao.getMobileByPrice(price);
	}


	@Override
	public List<Mobile> getAllMobilesDetails() {
		
		return dao.getAllMobilesDetails();
	}


	@Override
	public boolean validateFields() {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
