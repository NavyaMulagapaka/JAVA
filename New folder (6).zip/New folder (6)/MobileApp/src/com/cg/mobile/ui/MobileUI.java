package com.cg.mobile.ui;

import java.util.*;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.MobileServiceImpl;
import com.cg.mobile.service.iMobileService;

public class MobileUI {

	public static void main(String[] args) {
		
		iMobileService service = new MobileServiceImpl();
		System.out.println(service.display());
		
		Scanner sc= new Scanner(System.in);
		while(true)
		{
			System.out.println("1.insert");
			System.out.println("2.Update");
			System.out.println("3.View");
			System.out.println("4.Delete");
			System.out.println("5.Search");
			System.out.println("6.Exit");
			
			int opt =sc.nextInt();
			switch(opt)
			{
			case 1: break;
			case 2: break;
			case 3:
				List<Mobile> list1 = service.getAllMobilesDetails();
				for(Mobile m : list1)
				{
				System.out.println("----------------------------");
				System.out.println("id"+m.getMobileId());
				System.out.println("Name"+m.getName());
				System.out.println("Price"+m.getPrice());
				System.out.println("Quantity"+m.getQuantity());
				}
				break;
			case 4: break;
			case 5: 
				System.out.println("Enter price");
				double price =sc.nextDouble();
				List<Mobile> list = service.getMobileByPrice(price);
				for(Mobile m : list)
				{
					System.out.println("----------------------------");
					System.out.println("id"+m.getMobileId());
					System.out.println("Name"+m.getName());
					System.out.println("Price"+m.getPrice());
					System.out.println("Quantity"+m.getQuantity());
				}
			case 6: break;
			
			}
		}
		
	}

}
