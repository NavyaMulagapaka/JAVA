package com.cg.mobile.bean;



public class Customer {

	private String cName;
	private String mailId;
	private long phoneNumber;
	private int quantity;
	
	
	public Customer() {
		super();
	}


	public Customer(String cName, String mailId, long phoneNumber, int quantity) {
		super();
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNumber = phoneNumber;
		this.quantity = quantity;
	}


	public String getcName() {
		return cName;
	}


	public void setcName(String cName) {
		this.cName = cName;
	}


	public String getMailId() {
		return mailId;
	}


	public void setMailId(String mailId) {
		this.mailId = mailId;
	}


	public long getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
	
	
	
	
	
}
