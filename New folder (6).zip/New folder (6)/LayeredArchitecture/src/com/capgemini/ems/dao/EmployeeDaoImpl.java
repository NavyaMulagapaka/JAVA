package com.capgemini.ems.dao;

public class EmployeeDaoImpl implements EmployeeDao {

}
