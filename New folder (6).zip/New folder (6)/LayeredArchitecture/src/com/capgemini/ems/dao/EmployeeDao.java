package com.capgemini.ems.dao;

public interface EmployeeDao {

}
