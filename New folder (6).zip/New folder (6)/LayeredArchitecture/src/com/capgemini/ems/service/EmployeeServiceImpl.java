package com.capgemini.ems.service;

public class EmployeeServiceImpl implements EmployeeService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
