package com.capgemini.ems.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.service.EmployeeService;
import com.capgemini.ems.service.EmployeeServiceImpl;

public class EMSMain {
	public static void main(String[] args) {
		
		EmployeeService service=new EmployeeServiceImpl();
		
		
		System.out.println("Employee Management System");
		System.out.println("1.Add Employee");
		System.out.println("2.Exit");
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Select your choice");
		int option=0;
		try{
			
			option=	sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("Input should contain only digits");
			System.exit(0);
		}
		
		
		switch(option)
		{
		case 1:
			System.out.println("Enter id:");
			int id= sc.nextInt();
			System.out.println("Enter your name:");
			String name=sc.next();
			System.out.println("Enter your salary:");
			double salary=sc.nextDouble();
			
			Employee employee=new Employee(id, name, salary);
			
			
			break;
		case 2:
			System.out.println("Thank u visit again");
			System.exit(0);
			break;
		default:
			System.out.println("Invalid input try again");
			break;
		}
		
	}

}
