import org.apache.log4j.Logger;



public class Headache {

	public static void main(String[] args) {
		
		 Logger l= Logger.getLogger(Headache.class.getName());
		 l.error("hi ");
	}

}
