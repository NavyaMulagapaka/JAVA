package com.cg.jpa;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;







public class EmployeeDetails {

	public static void main(String[] args) {
		
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("Employeejpa");
		
		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Employee emp= new Employee();
		
		System.out.println("1.add"+'\n'+"2.update"+'\n'+"3.delete"+'\n'+"4.view"+'\n'+"5.search by id"+'\n'+"6.exit");
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Eneter any option");
		int n= sc.nextInt();
		
		switch(n)
		{
		
		case 1: System.out.println("Enter Employ name");
				emp.setName(sc.next());
				System.out.println("Enter Employee salary");
				emp.setSalary(sc.nextDouble());
				
				em.persist(emp);
				em.getTransaction().commit();
				em.close();
				break;
				
				
		case 2:
			System.out.println("Enter Id of the employee to be updated");
			Employee emp1= em.find(Employee.class, sc.nextInt());
			
			if(emp1==null)
			{
				System.out.println("id not present");
			}
			else
			{
				
				System.out.println("Id is present Enter details");
				System.out.println("Enter employee name");
				emp1.setName(sc.next());
				System.out.println("Eneter employee salary");
				emp1.setSalary(sc.nextDouble());
				em.persist(emp1);
				em.getTransaction().commit();	
				em.close();
			}
			break;
		
		case 3:
			Employee emp2= new Employee();
			System.out.println("Enter Employee Id to be deleted");
			
			emp2= em.find(Employee.class, sc.nextInt());
			em.remove(emp2);
			em.getTransaction().commit();
			em.close();
			System.out.println("Deleted Successfully");
			break;
			
			
		case 4:
			Employee emp3= new Employee();
			Query q = em.createQuery("select emp from Employee emp ");
			
			List <Employee> list = q.getResultList();
			
			for(Employee emp4:list)
			{
				System.out.println("-------------------------");
				System.out.println("ID:"+emp4.getId());
				System.out.println("Name"+emp4.getName());
				System.out.println("Price"+emp4.getSalary());
			}
			em.persist(emp3);
			em.getTransaction().commit();
			em.close();
			break;
			
		case 5:
			Employee emp5= new Employee();
			System.out.println("Eneter employee id to be searched");
			int i=sc.nextInt();
			emp5= em.find(Employee.class, i);
			if(emp5==null)
			{
				System.out.println("id not present");
			}
			
			else
			{
				Query q1 = em.createQuery("select emp from Employee emp");
				
				
				List <Employee> list1 = q1.getResultList();
				
				
					System.out.println("-------------------------");
					System.out.println("ID:"+emp5.getId());
					System.out.println("Name"+emp5.getName());
					System.out.println("Price"+emp5.getSalary());
					em.persist(emp5);
					em.getTransaction().commit();
					em.close();
				
			}
			break;
			
		case 6: break;
				
		
		
		}
		
		emf.close();
		

	}

}
