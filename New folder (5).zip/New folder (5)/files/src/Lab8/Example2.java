package Lab8;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Example2 {

	public static void main(String[] args) throws FileNotFoundException {
		try {
			FileOutputStream fout= new FileOutputStream("D:\\JavaFiles\\second.txt");
			String s="Helo pooja";
			byte b[]=s.getBytes();
			fout.write(b);
			fout.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
			
		
	}

}
