package Lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class reverseString {

	public static void main(String[] args) throws FileNotFoundException {
		FileInputStream fin= new FileInputStream("D:\\JavaFiles\\first.txt");
		FileOutputStream fout= new FileOutputStream("D:\\JavaFiles\\second.txt");
		int i=0;
		try {
				String input="";
			while((i=fin.read())!=-1)
			{
				input=input+(char)i;
			}
			System.out.println(input);
			
			StringBuilder input1 = new StringBuilder(); 
			input1.append(input);
			input1 = input1.reverse(); 
			System.out.println(input1);
			
			
			String s=input1.toString();
			byte b[]=s.getBytes();
			fout.write(b);
			
			fin.close();
			fout.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
