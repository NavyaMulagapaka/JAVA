
public class Hello {

	public static void main(String[] args) {
		int a=10,b=20;
		if(a==10&&b==30)
		{
			System.out.println("Hello world");
		}
		if(a==10&&b==20)
		{
			System.out.println("Good Morning");
		}

	}

}
