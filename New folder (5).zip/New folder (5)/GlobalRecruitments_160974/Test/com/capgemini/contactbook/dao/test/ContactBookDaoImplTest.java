package com.capgemini.contactbook.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImplTest {

	ContactBookDaoImpl dao = null;

	@Before
	public void setUp() {
		dao = new ContactBookDaoImpl();
	}

	@After
	public void tearDown() {
		dao = null;
	}

	@Test
	public void addEnquiry() {
		
		EnquiryBean addEnquiryDetails = new EnquiryBean();
		addEnquiryDetails.setfName("Anii");
		addEnquiryDetails.setlName("Mal");
		addEnquiryDetails.setContactNo("9099090990");
		addEnquiryDetails.setpDomain("Java");
		addEnquiryDetails.setpLocation("Hyderabad");
		
		try {
			Integer enqryId = dao.addEnquiry(addEnquiryDetails);
			assertNotNull(enqryId);
			System.out.println("Successfully proved the Test Case for Adding Details.");

		} catch (ContactBookException e) {
			System.err.println("Test Case failed for Adding Details");
		}
	}
	
	@Test
	public void getEnquiryDetails() {
		EnquiryBean searchEnquiry;

		try {
			searchEnquiry = dao.getEnquiryDetails(1002);
			assertEquals("Anii", searchEnquiry.getfName());
			System.out.println("Successfully proved the Test Case for Search Operation.");

		} catch (ContactBookException e) {
			System.err.println("Test Case failed for Search Operation");
		}
	}
}
