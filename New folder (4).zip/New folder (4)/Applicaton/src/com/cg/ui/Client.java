package com.cg.ui;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.helathcare.exceptions.HealthCareException;
import com.cg.service.patientService;
public class Client {



			static Logger logger = Logger.getLogger(Client.class);

			public static void main(String[] args) throws HealthCareException {

				PropertyConfigurator.configure("resource/log4j.properties");
				logger.info("log4j file loaded...");

				Scanner scanner = new Scanner(System.in);

				patientService service = new patientServiceImpl();

				System.out.println("welcome to  Health carew Application");
				System.out.println("1.fix appoinment");
				System.out.println("2.search");
				System.out.println("3.exit");

				System.out.println("Select ur choice");
				int choice = 0;
				try {
					choice = scanner.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("enter only digits");
					System.exit(0);
				}
				switch (choice) {
				case 1:
					scanner.nextLine();
					System.out.println("Enter name:");
					String name = scanner.nextLine();
					System.out.println("Enter MobileNumber:");
					long phone = 0;
					try {
						phone = scanner.nextLong();
					} catch (InputMismatchException e) {
						System.err.println("phone number should contain only digits");
						System.exit(0);
					}
					scanner.nextLine();
					System.out.println("problem Name");
					String problemName = scanner.nextLine();

					Patient patient = new Patient();
					patient.setMobileNo(phone);
					patient.setName(name);
					patient.setProblem(problemName);

					try {
						boolean result = service.validateDetails(patient);

						if (result) {
							int patientId = service.fixAppointment(patient);
							System.out.println("ur appoiinment fixed with the id: " + patientId);
						}

					} catch (HealthCareException e) {
						System.err.println(e.getMessage());
					}

					break;
					
				case 2:
					System.out.println("Eneter id");
					int id= scanner.nextInt();
					List<Patient> list1 = service.getPatientDetails(id);
					for(Patient p : list1)
					{
					System.out.println("----------------------------");
					System.out.println("id= "+p.getId());
					System.out.println("Name= "+p.getName());
					System.out.println("Mobile NO"+p.getMobileNo());
					System.out.println("Doctor name"+p.getDoctorName());
					System.out.println("Problem"+p.getProblem());
					System.out.println("Application date"+p.getDate());
					}
					break;
					
				default:
					break;
				}

			}

		}

	}

}
