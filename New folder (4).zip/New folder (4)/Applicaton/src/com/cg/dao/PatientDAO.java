package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.bean.PatientBean;
import com.cg.helathcare.exceptions.HealthCareException;
import com.cg.helathcare.utility.JdbcUtility;

public class PatientDAO implements IPatientDAO {

	
	static Logger logger = Logger.getLogger(PatientDAO.class);

	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public int fixAppointment(PatientBean patient) throws HealthCareException {
		logger.info("in fix appoiment method..");

		int patientId = 0;

		connection = JdbcUtility.getConnection();
			try {
				statement = connection.prepareStatement(QuieryConstants.insertQuery);
				statement.setString(1, patient.getPatientName());
				statement.setLong(2, patient.get);
				statement.setString(3, doctorname);
				statement.setString(4, patient.getProblem());
				statement.executeUpdate();

				statement = connection.prepareStatement(QueryConstants.getIdQuery);
				ResultSet resultSet = statement.executeQuery();
				resultSet.next();

				patientId = resultSet.getInt(1);

			} catch (SQLException e) {
				logger.error("statement not created..");
				throw new HealthCareException("statement not created");

			}
		} 

		return patientId;
	}

	@Override
	public String getDoctorName(String problemName) throws HealthCareException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PatientBean> getPatientDetails(int id)
			throws HealthCareException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

}
