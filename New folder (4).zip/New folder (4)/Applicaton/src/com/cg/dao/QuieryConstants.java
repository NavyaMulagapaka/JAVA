package com.cg.dao;

public class QuieryConstants {
	public static final String insertQuery = "insert into patients_table values(patient_sequence.nextval,?,?,?,?,sysdate)";
	public static final String detailsQuery="select * from patients_table where id=?";
	public static final String getIdQuery = "select max(id) from patients_table";
	
	
	
}
