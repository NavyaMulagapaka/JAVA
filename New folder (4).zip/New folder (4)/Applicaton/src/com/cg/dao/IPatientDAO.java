package com.cg.dao;

import java.util.List;



import com.cg.bean.PatientBean;
import com.cg.helathcare.exceptions.HealthCareException;

public interface IPatientDAO {

	int fixAppointment(PatientBean patient) throws HealthCareException;
	public String getDoctorName(String problemName) throws HealthCareException;
	public List<PatientBean> getPatientDetails(int id) throws HealthCareException ;

	
	
	
}
