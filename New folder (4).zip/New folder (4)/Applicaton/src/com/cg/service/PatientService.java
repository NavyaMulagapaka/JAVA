package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.PatientBean;
import com.cg.helathcare.exceptions.HealthCareException;

public class PatientService implements IPatientService {

	@Override
	public boolean validateDetails(PatientBean patient)
			throws HealthCareException {
		List<String> list = new ArrayList<>();
		boolean result = false;

		if (!isNameValid(patient.getPatientName())) {
			list.add("name should start with capital letter & length should be greater than 6 and less tah 20");
		}
		if (!isPhonevalid(patient.getPhone())) {
			list.add("phone number exactly 10 digits");
		}
		if (!isProblemValid(patient.getDescription())) {
			list.add("problem name should contain characters");
		}

		if (!list.isEmpty()) {
			result = false;
			throw new HealthCareException(list + "");
		} else {
			result = true;
		}
		return result;
	}

	@Override
	public int fixAppointment(PatientBean patient) throws HealthCareException {
		
		return 0;
	}

	@Override
	public List<PatientBean> getPatientDetails(int id)throws HealthCareException {
		
		return null;
	}
	
	public boolean isNameValid(String name) {

		String nameRegEx = "[A-Z]{1}[a-zA-Z]{5,20}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}

	public boolean isPhonevalid(long mobileNo) {

		String phoneregEx = "[0-9]{10}";
		Pattern pattern = Pattern.compile(phoneregEx);
		Matcher matcher = pattern.matcher(String.valueOf(mobileNo));
		return matcher.matches();
	}

	public boolean isProblemValid(String problemName) {

		String nameRegEx = "[a-zA-Z]{3,}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(problemName);
		return matcher.matches();
	}

	

}
