package com.cg.service;
import java.util.List;

import com.cg.bean.PatientBean;

import com.cg.helathcare.exceptions.HealthCareException;

public interface IPatientService {

	
	
	

	
	

		boolean validateDetails(PatientBean patient) throws HealthCareException;

		int fixAppointment(PatientBean patient) throws HealthCareException;

		public List<PatientBean> getPatientDetails(int id) throws HealthCareException;

	

}
