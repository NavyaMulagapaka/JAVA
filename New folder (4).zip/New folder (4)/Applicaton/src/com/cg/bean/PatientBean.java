package com.cg.bean;

import java.sql.Date;

public class PatientBean {

	private int id;
	private String patientName;
	private int age;
	private long phone;
	private String description;
	private Date consultationDate;

	public PatientBean() {
		super();
	}

	public PatientBean(int id, String patientName, int age, long phone,
			String description, Date consultationDate) {
		super();
		this.id = id;
		this.patientName = patientName;
		this.age = age;
		this.phone = phone;
		this.description = description;
		this.consultationDate = consultationDate;
	}

	

}
