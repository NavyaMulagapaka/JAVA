package com.cg.operators;


 class Company{
	 
	 String K="This is parent class";
 }

public class Class8 extends Company {

	public void check(){
		System.out.println("Sucess"+K);
		
	}
	public void view(Company x)
	{
		if(x instanceof Class8)
		{
			//Class8 b1= new Class8();
			Class8 b1= (Class8) x;
			b1.check();
			System.out.println("Sucess"+K);
		}
		
	}


	public static void main(String[] args) {
		
		Class8 c= new Class8();
		c.view(c);
	}

}
