package com.cg.operators;

public class Class3 {

	public static void main(String[] args) {
		int num1=56,num2=78;
		
		System.out.println("num1>num2 = "+(num1>num2));
		
		System.out.println("num1,num2 = "+(num1<num2));
		
		System.out.println("num1>=num2 = "+(num1>=num2));
		
		System.out.println("num1<=num2 = "+(num1<=num2));
		
		System.out.println("num1==num2 = "+(num1==num2));
		
		System.out.println("num1!=num2 = "+(num1!=num2));

	}

}
