package com.cg.operators;

public class Class2 {

	public static void main(String[] args) {
		int n=7;
		System.out.println("Pre Increment is"+(++n));
		
		int p=8;
		System.out.println("Pre Decrement is"+(--p));
		
		int q=5;
		System.out.println("Post Increment is"+(q++));
		
		int r=20;
		System.out.println("Post Decrement is"+(r--));
		
		
		
	}

}
