package com.cg.operators;

public class Class1 {

	public static void main(String[] args) {
		
		int num1=18,num2=5;
		
		System.out.println("Addition of two numbers is = "+(num1+num2));
		
		System.out.println("Subtraction of two numbers is = "+(num1-num2));
		
		System.out.println("Multi[plication of two numbers of two numbers is = "+(num1*num2));
		
		System.out.println("Division of two numbers is = "+(((double)(num1)/(num2))));
		
		System.out.println("Remiainder of two numbers is = "+(num1%num2));
		
		
		
		
		
	}

}
