package com.cg.operators;

public class Class4 {

	public static void main(String[] args) {
		boolean bool1=true,bool2=false;
		
		
		System.out.println("bool1&&bool2 = "+(bool1&&bool2));
		
		System.out.println("bool1||bool2 = "+(bool1||bool2));
		
		System.out.println("bool1!bool2 = "+(bool1!=bool2));
		
		
		
		
		
		String out;
		
		int a=6,b=12;
		out = a==b ? "yes":"No";
		System.out.println("Ans :"+out);
		
	}

}
