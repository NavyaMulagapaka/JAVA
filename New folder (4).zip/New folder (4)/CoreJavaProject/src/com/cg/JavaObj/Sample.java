package com.cg.JavaObj;

public interface Sample {

	void run();
	protected boolean isValid();
	
}
