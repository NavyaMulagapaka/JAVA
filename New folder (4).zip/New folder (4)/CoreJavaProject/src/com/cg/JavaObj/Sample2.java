package com.cg.JavaObj;

public interface Sample2 {
void run2();
}
