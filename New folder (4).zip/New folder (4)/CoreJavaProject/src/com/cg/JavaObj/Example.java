package com.cg.JavaObj;

 class Example {

	int x;
	String r;
	
	public void isValid()
	{
		System.out.println("uefhui");
	}

}
 class Example1 extends Example{
	
	
	
}