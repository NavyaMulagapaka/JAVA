package com.cg.JavaObj;

public class SampleImpl implements Sample,Sample2 {

	

	@Override
	public void run2() {
		// TODO Auto-generated method stub
		
	}

	
	public void run() {
		// TODO Auto-generated method stub
		
	}

	
	public static void main(String args[]){  
		   String s1="Sachin";  
		   String s2="Sachin";  
		   String s3=new String("Sachin");  
		   String s4="SACHIN";  
		   System.out.println(s1.equals(s2));//true  
		   System.out.println(s1.equals(s3));//true  
		   System.out.println(s1.equalsIgnoreCase(s4));//false  
		   System.out.println(s1==s3);
		   System.out.println(s1.compareTo(s3));
		 }  
}
