package com.cg.JavaObj;


 class Animal{  
void eat(){System.out.println("eating");}  
}  
class Dog extends Animal{  
void eat(){System.out.println("eating fruits");}  
}  

public class Student extends Animal{  
	
void eat(){System.out.println("drinking milk");
} 

	
public static void main(String args[]){  
	
Animal a1,a2;  
a1=new Animal();  
a2=new Dog();  
Animal a3=new Student();  
a1.eat();  
a2.eat();  
a3.eat();  
}  
}  



