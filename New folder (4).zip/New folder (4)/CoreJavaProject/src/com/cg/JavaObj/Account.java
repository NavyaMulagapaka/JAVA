package com.cg.JavaObj;

public class Account {

	public static void main(String[] args) {
		int id=101;
		String name="Aryan";
		double amt=25000;
		System.out.println(id+" "+name+" ");
		
		System.out.println("Deposited amount ="+calDeposit(amt));
		
		System.out.println("With drawn amount is"+calWithDraw(amt));
		
		System.out.println("Balance amount is" +calCheckBalance(amt));
	
		
	}
	
	public static double calDeposit(double amt)
	{
		return amt;
	}
	public static double calWithDraw(double amt)
	{
		double w=4000;
		return (w);
	}
	
	public static double calCheckBalance(double amt)
	{
		double w=calWithDraw( amt);
		return (amt-w);
	}
}
