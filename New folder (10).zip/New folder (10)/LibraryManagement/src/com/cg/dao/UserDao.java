package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UserDao {

	Connection con = null;
	PreparedStatement ps = null;
	
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			
			con=DriverManager.getConnection(url, user, pass);
			System.out.println("connected");
			return con;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return con;
	}
	
	public String getUserStatus(String user) {
		String s=null;
		try {
			con = getConnection();
			ps = con.prepareStatement("select librarian from user_info where user_name=?");
			ps.setString(1,user);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
			s= rs.getString("librarian");
			}
			return s;
			
			
		} catch(Exception e) {e.printStackTrace();}
		return null;
	}
	
	public int add(String RegId,String BookId,String userId)
	{
		 con=getConnection();
		 
		 String sql="insert into book_registration values(?,?,?,sysdate)";
		 
		 try {
			ps=con.prepareStatement(sql);
			
			ps.setString(1, RegId);
			ps.setString(2,BookId);
			ps.setString(3,userId);
			
			
			int n= ps.executeUpdate();
			
		
			return n;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		 
		 return 0;
	}
	
}
